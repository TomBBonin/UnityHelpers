﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TunnelDemo : MonoBehaviour 
{
    public Material  TunnelMat;
    public Transform Tunnels;
    public bool Loop;
    public bool FlipNormals;
    public int  CurveRes;
    public int  TunnelRes;
    public int  Radius;
    public List<DraggingSphere> Points;

    private Tunnel _tunnel;
    private const int NBStartPoints = 4;
    Vector3[] Vpos =
    {
        new Vector3(150, -50, -100), 
        new Vector3(300,  50, 0), 
        new Vector3(450, -50, -100), 
        new Vector3(600,  50, 0)
    };

    public void ChangeCurve_Loop(bool loop)
    {
        Loop = loop;
        _tunnel.Loop = Loop;
        _tunnel.Rebuild();
    }

    public void ChangeCurve_Normals(bool flip)
    {
        FlipNormals = flip;
        _tunnel.FlipWallNormals = flip;
        _tunnel.Rebuild();
    }

    public void ChangeCurve_CurveRes(bool increase)
    {
        CurveRes += increase ? 1 : -1;
        _tunnel.Resolution_Curve = CurveRes;
        _tunnel.Rebuild();
    }

    public void ChangeCurve_WallRes(bool increase)
    {
        TunnelRes += increase ? 1 : -1;
        _tunnel.Resolution_Walls = TunnelRes;
        _tunnel.Rebuild();
    }

    public void ChangeCurve_Radius(bool increase)
    {
        Radius += increase ? 1 : -1;
        _tunnel.Radius = Radius;
        _tunnel.Rebuild();

        foreach (DraggingSphere point in Points)
            point.UpdateView(Radius);
    }

    public void ChangeCurve_NbPoints(bool increase)
    {
        if (increase)
        {
            GameObject point = new GameObject();
            point.name = "Point_" + Points.Count;
            point.transform.parent = _tunnel.Obj.transform;
            point.transform.position = new Vector3(350, 0, 0);
            DraggingSphere dragPoint = point.AddComponent<DraggingSphere>();
            dragPoint.Init(Radius);
            Points.Add(dragPoint);
        }
        else
        {
            Destroy(Points[Points.Count - 1].gameObject);
            Points.RemoveAt(Points.Count - 1);
        }

        Vector3[] newPoints = new Vector3[Points.Count];
        for (int i = 0; i < Points.Count; i++)
            newPoints[i] = Points[i].transform.position;
        _tunnel.UpdatePoints(newPoints);
        _tunnel.Rebuild();
    }

    public void ChangeCurve_Reset()
    {
        // if destroy
        if (_tunnel != null)
        {
            Destroy(_tunnel.Obj);
            foreach (DraggingSphere point in Points)
                Destroy(point.gameObject);
            _tunnel = null;
            Points = null;
        }

        Loop = false;
        FlipNormals = false;
        CurveRes = 10;
        TunnelRes = 10;
        Radius = 15;

        _tunnel = new Tunnel(TunnelMat, Tunnels);
        _tunnel.Loop             = Loop;
        _tunnel.FlipWallNormals  = FlipNormals;
        _tunnel.Resolution_Curve = CurveRes;
        _tunnel.Resolution_Walls = TunnelRes;
        _tunnel.Radius           = Radius;

        Points = new List<DraggingSphere>(NBStartPoints);
        for (int i = 0; i < NBStartPoints; i++)
        {
            GameObject point = new GameObject();
            point.name = "Point_" + i;
            point.transform.parent = _tunnel.Obj.transform;
            point.transform.position = Vpos[i];
            DraggingSphere dragPoint = point.AddComponent<DraggingSphere>();
            dragPoint.Init(Radius);
            Points.Add(dragPoint);

        }
        Vector3[] newPoints = new Vector3[Points.Count];
        for (int i = 0; i < Points.Count; i++)
            newPoints[i] = Points[i].transform.position;
        _tunnel.UpdatePoints(newPoints);
        _tunnel.Rebuild();
    }

    private void Update()
    {
        if (_tunnel != null)
            _tunnel.Execute(Time.deltaTime);

        foreach (DraggingSphere point in Points)
        {
            if (point.Dragging)
            {
                Vector3[] newPoints = new Vector3[Points.Count];
                for (int i = 0; i < Points.Count; i++)
                    newPoints[i] = Points[i].transform.position;
                _tunnel.UpdatePoints(newPoints);
                _tunnel.Rebuild();
                break;
            }
        }
    }

    public void OnDrawGizmos()
    {
        _tunnel.OnDrawGizmos();
    }
}
