﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UI_Manager_TunnelTest : MonoBehaviour 
{
    public TunnelDemo TunnelTest;
    public Button[] ButtonGroup_Loop;
    public Button[] ButtonGroup_FlipNormals;
    public Button[] ButtonGroup_CurveRes;
    public Button[] ButtonGroup_WallRes;
    public Button[] ButtonGroup_Radius;
    public Button[] ButtonGroup_Points;
    public Text     Label_CurveRes;
    public Text     Label_WallRes;
    public Text     Label_Radius;
    public Text     Label_Points;

	void Start () 
    {
        ButonEvent_Reset();
    }
	
	void Update () { }

    public void ButtonEvent_LoopCurve(bool loop)
    {
        TunnelTest.ChangeCurve_Loop(loop);
        ButtonGroup_Loop[0].interactable = !TunnelTest.Loop;
        ButtonGroup_Loop[1].interactable =  TunnelTest.Loop;
    }

    public void ButtonEvent_FlipNormals(bool flip)
    {
        TunnelTest.ChangeCurve_Normals(flip);
        ButtonGroup_FlipNormals[0].interactable = !TunnelTest.FlipNormals;
        ButtonGroup_FlipNormals[1].interactable =  TunnelTest.FlipNormals;
    }

    public void ButtonEvent_ChangeCurveRes(bool increase)
    {
        TunnelTest.ChangeCurve_CurveRes(increase);
        Label_CurveRes.text = TunnelTest.CurveRes.ToString();
        ButtonGroup_CurveRes[0].interactable = !(TunnelTest.CurveRes <= 1);
        ButtonGroup_CurveRes[1].interactable = !(TunnelTest.CurveRes >= 99);
    }

    public void ButtonEvent_ChangeWallRes(bool increase)
    {
        TunnelTest.ChangeCurve_WallRes(increase);
        Label_WallRes.text = TunnelTest.TunnelRes.ToString();
        ButtonGroup_WallRes[0].interactable = !(TunnelTest.TunnelRes <= 3);
        ButtonGroup_WallRes[1].interactable = !(TunnelTest.TunnelRes >= 99);
    }

    public void ButtonEvent_ChangeRadius(bool increase)
    {
        TunnelTest.ChangeCurve_Radius(increase);
        Label_Radius.text = TunnelTest.Radius.ToString();
        ButtonGroup_Radius[0].interactable = !(TunnelTest.Radius <= 1);
        ButtonGroup_Radius[1].interactable = !(TunnelTest.Radius >= 99);
    }

    public void ButtonEvent_ChangeNbPoints(bool increase)
    {
        TunnelTest.ChangeCurve_NbPoints(increase);
        Label_Points.text = TunnelTest.Points.Count.ToString();
        ButtonGroup_Points[0].interactable = !(TunnelTest.Points.Count <= 2);
        ButtonGroup_Points[1].interactable = !(TunnelTest.Points.Count >= 99);
    }

    public void ButonEvent_Reset()
    {
        TunnelTest.ChangeCurve_Reset();

        ButtonGroup_Loop[0].interactable = !TunnelTest.Loop;
        ButtonGroup_Loop[1].interactable =  TunnelTest.Loop;

        ButtonGroup_FlipNormals[0].interactable = !TunnelTest.FlipNormals;
        ButtonGroup_FlipNormals[1].interactable =  TunnelTest.FlipNormals;

        Label_CurveRes.text = TunnelTest.CurveRes.ToString();
        Label_WallRes.text  = TunnelTest.TunnelRes.ToString();
        Label_Radius.text   = TunnelTest.Radius.ToString();
        Label_Points.text   = TunnelTest.Points.Count.ToString();
    }
}
