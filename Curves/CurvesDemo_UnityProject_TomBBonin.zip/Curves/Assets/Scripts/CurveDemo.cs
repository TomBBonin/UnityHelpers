﻿using Curves;
using UnityEngine;

public class CurveDemo : MonoBehaviour
{
    public Transform[] ControlPoints;
    public Transform BezierFollowerView;
    public Transform CatmullRomFollowerView;

    private Bezier _bezier;
    private CurveFollower _bezierFollower;
    private CurvedMesh _bezierMesh;

    private CatmullRom _catmullRom;
    private CurveFollower _catmullRomFolllower;
    private CurvedMesh _catmullRomMesh;

    private float _time;
    private const float CurveFollowerSpeed = 10f;
    private const int CurveResolution = 10;

    public void Awake()
    {
        // turn Transforms into useable vector3 array
        var controlPoints = new Vector3[ControlPoints.Length];
        for (var i = 0; i < ControlPoints.Length; i++)
            controlPoints[i] = ControlPoints[i].position;

        // create curve and follower : Bezier
        _bezier = new Bezier(CurveResolution, controlPoints);
        _bezierFollower = new CurveFollower();
        ResetFollowerToCurveStart(_bezierFollower, _bezier, BezierFollowerView);
        _bezierFollower.Evt_ReachedEnd += OnBezierFollowerReachedEnd;

        // create curve and follower : CatmullRom
        _catmullRom = new CatmullRom(CurveResolution, controlPoints, true);
        _catmullRomFolllower = new CurveFollower();
        ResetFollowerToCurveStart(_catmullRomFolllower, _catmullRom, CatmullRomFollowerView);
        _catmullRomFolllower.Evt_ReachedEnd += OnCatmullRomFollowerReachedEnd;

        // create tunnel mesh along curve
        _bezierMesh = new CurvedMesh(_bezier, new Material(Shader.Find("Standard")), transform);
        _catmullRomMesh = new CurvedMesh(_catmullRom, new Material(Shader.Find("Standard")), transform);
    }

    private void Update()
    {
        _time += Time.deltaTime;

        // move followers on the curve
        _bezierFollower.MoveAlongCurve(_time, BezierFollowerView);
        _catmullRomFolllower.MoveAlongCurve(_time, CatmullRomFollowerView);
    }

    private void OnBezierFollowerReachedEnd(float reachedEndTime)
    {
        ResetFollowerToCurveStart(_bezierFollower, _bezier, BezierFollowerView);
    }

    private void OnCatmullRomFollowerReachedEnd(float reachedEndTime)
    {
        ResetFollowerToCurveStart(_catmullRomFolllower, _catmullRom, CatmullRomFollowerView);
    }

    private void ResetFollowerToCurveStart(CurveFollower follower, Curve curve, Transform view)
    {
        Vector3 pos;
        Quaternion rot;
        follower.StartMoving(_time, curve, out pos, out rot, CurveFollowerSpeed);
        view.position = pos;
        view.rotation = rot;
    }

    private void OnDrawGizmos()
    {
        if (_bezier != null)
            _bezier.Draw();
        
        if(_catmullRom != null)
            _catmullRom.Draw();
    }
}