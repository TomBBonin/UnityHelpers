﻿/* 
 * "Complex" Demo for the Hex Grid Builder
 * For the bare bones check the Git Repo
 * 
 * https://github.com/tombbonin
 */ 

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

// Create your own HexGridActor class
public class Demo_HexGridActor : HexGridActor
{
    private Vector2 _target;
    private CatmullRom _path;
    private CatmullRomFollower _pathFollower;
    public  CatmullRomFollower PathFollower { get { return _pathFollower; } }

    public Demo_HexGridActor(GameObject obj) : base(obj) { }

    public void ResetPathFollowing(Vector2 target, Vector2[] path, float speed)
    {
        _target = target;

        if (_path == null)
            _path = new CatmullRom();
        if (_pathFollower == null)
            _pathFollower = new CatmullRomFollower();

        _path.CloseLoop = false;
        _path.SplineResolution = 10;
        _path.SplineColor = Color.blue;

        _path.ControlPoints = new Vector3[path.Length];
        _path.ControlPoints[0] = new Vector3(Obj.transform.position.x, 0, Obj.transform.position.z); // Hack to start from current world pos instead of center of tile
        for (int i = 1; i < path.Length; i++)
            _path.ControlPoints[i] = Grid.Tiles[path[i]].Obj.transform.position;

        _path.Init();
        _pathFollower.StartMoving(Obj.transform, _path, speed);
    }

    override public void Execute(float deltaTime)
    {
        if (_pathFollower == null)
            return;

        _pathFollower.MoveAlongCurve();
        Vector2 newPos = Grid.ToHex(new Vector2(Obj.transform.position.x, Obj.transform.position.z));
        Pos = newPos;

        if (Pos == _target)
            Grid.RemoveActor(this);
    }
}

// Create your own HexTile class
public class Demo_HexTile : HexTile
{
    public Demo_HexTile(GameObject obj) : base(obj) { }
}

// Create your own HexGrid Class
public class Demo_HexGrid : HexGrid
{
    public Demo_HexGrid(GameObject obj,GameObject tilesObj, GameObject actorsObj, Vector2 size, float radius, float width) : base(obj, tilesObj, actorsObj, size, radius, width) { }
}

// Create your own GridBuilder Class
public class Demo_HexGridBuilder : HexGridBuilder
{
    #region Variable Declaration

    private HexGrid _grid;

    // UI information used in OnTileEnter
    public int[]   TerritoryOverlayIdx    { get; set; }
    public Color[] TerritoryOverlayColor  { get; set; }
    public int     HoverOverlayRange      { get; set; }
    public int     HoverOverlayIdxToApply { get; set; }

    // Used to demonstrate Pathfinding
    private CatmullRom    _pathCurve;
    private Vector2       _pathStart;
    private Vector2       _pathEnd;

    public GameObject BlockerPrefab;
    public GameObject StartPrefab;
    public GameObject EndPrefab;
    public GameObject ActorPrefab;

    private HexGridActor _startActor;
    private HexGridActor _endActor;

    private const float ActorSpeed = 20f;
    private const float ActorSpawnRate = 2f;
    private float _spawnTimer;

    private int _gridPreset;
    #endregion

    private void Awake()
    {
        // UI inits
        TerritoryOverlayIdx = new int[3];
        TerritoryOverlayColor = new Color[3];
        HoverOverlayRange = 1;
        HoverOverlayIdxToApply = 2;

        // Used to visualize Pathfinding
        _pathCurve = new CatmullRom();
        _pathCurve.CloseLoop = false;
        _pathCurve.SplineResolution = 10;
        _pathCurve.SplineColor = Color.magenta;
        _pathStart = new Vector2(-1, -1);
        _pathEnd   = new Vector2(-1, -1);

        _spawnTimer = 0f;
    }

    #region Actor Pathfinding

    private void UpdateAllActorsPathfind()
    {
        // Here is an example of how to use the function Timer. It's useful to see how long it takes
        // to execute a block of code. Here it is used to time the difference between performing one
        // AStar algorithm per actor, or performing a single floodfill algorithm and extracting paths from
        // it. My measurements indicate for example that on this size of Grid, on average, with more than 2 actors,
        // using the floodfill approach is quicker. /!\ This can wildly differ based on the space you are searching
        // through, the proximity to the goal, the number of actors, etc. Test it yourself to find out what's the best
        // in your specific case!

        // Uncomment the Astar section to compare!

        //FunctionTimer.START_FUNCTION_TIMER("WithAStar");
        //WithAStar();
        //FunctionTimer.STOP_FUNCTION_TIMER("WithAStar");

        FunctionTimer.START_FUNCTION_TIMER("WithFloodFill");
        WithFloodFill();
        FunctionTimer.STOP_FUNCTION_TIMER("WithFloodFill");

        // Uncomment this section to display execution time
        //FunctionTimer.DISPLAY_FUNCTION_TIMER_AVERAGE("WithAStar");
        //FunctionTimer.DISPLAY_FUNCTION_TIMER_AVERAGE("WithFloodFill");
    }

    private void WithFloodFill()
    {
        Dictionary<Vector2, Vector2> floodFillCoords;
        _grid.Pathfind_FloodFill(_endActor.Pos, out floodFillCoords);
        UpdateDisplayWithFloodFill(floodFillCoords);
        foreach (Demo_HexGridActor actor in _grid.Actors)
            if (actor.PathFollower != null)
                UpdateActorPathfindFloodFill(actor, floodFillCoords);
    }

    private void UpdateDisplayWithFloodFill(Dictionary<Vector2, Vector2> floodFill)
    {
        List<Vector2> path;
        HexGrid.Pathfind_Floodfill_GetPath(_startActor.Pos, out path, floodFill);
        _pathCurve.ControlPoints = new Vector3[path.Count];
        for (int i = 0; i < path.Count; i++)
            _pathCurve.ControlPoints[i] = _grid.Tiles[path[i]].Obj.transform.position;
        _pathCurve.Init();
    }

    private void UpdateActorPathfindFloodFill(Demo_HexGridActor actor, Dictionary<Vector2, Vector2> floodFill)
    {
        List<Vector2> path;
        HexGrid.Pathfind_Floodfill_GetPath(actor.Pos, out path, floodFill);
        actor.ResetPathFollowing(_endActor.Pos, path.ToArray(), ActorSpeed);
    }

    private void WithAStar()
    {
        UpdateDisplayPathAStar();
        foreach (Demo_HexGridActor actor in _grid.Actors)
            if (actor.PathFollower != null)
                UpdateActorPathfindAStar(actor);
    }

    private void UpdateDisplayPathAStar()
    {
        List<Vector2> path;
        _grid.Pathfind_AStar(_startActor.Pos, _endActor.Pos, out path);
        _pathCurve.ControlPoints = new Vector3[path.Count];
        for (int i = 0; i < path.Count; i++)
            _pathCurve.ControlPoints[i] = _grid.Tiles[path[i]].Obj.transform.position;
        _pathCurve.Init();
    }

    private void UpdateActorPathfindAStar(Demo_HexGridActor actor)
    {
        List<Vector2> path;
        _grid.Pathfind_AStar(actor.Pos, _endActor.Pos, out path);
        actor.ResetPathFollowing(_endActor.Pos, path.ToArray(), ActorSpeed);
    }

    #endregion

    private void Update()
    {
        if (_grid != null)
            _grid.Execute(Time.deltaTime);

        if (_pathStart == new Vector2(-1, -1) || _pathEnd == new Vector2(-1, -1))
            return;

        // Spawn an actor every x seconds
        _spawnTimer -= Time.deltaTime;
        if (_spawnTimer <= 0)
        {
            _spawnTimer += ActorSpawnRate;
            Demo_HexGridActor actor = CreateActor("Actor", _startActor.Pos, _grid, 0, ActorPrefab) as Demo_HexGridActor;
            UpdateActorPathfindAStar(actor);
        }
    }

    void OnDrawGizmos()
    {
        if(_pathCurve != null)
            _pathCurve.OnDrawGizmos();
    }

    // Using the base method CreateHexGrid() as an example, create yor own grid building method 
    // Change the new HexGrid call to use your class that inherits from HexGrid
    // Add or remove any Tiles as you see fit this demo for a more appealing and symetrical board
    // You can use the owner parameter to affect an owner to tiles. Every owner's group of tiles will have their own border. 
    //     Remember to add one material per owner to the border overlays.
    private Demo_HexGrid CreateDemoHexGrid()
    {
        ComputeHexDimensions();
        BuildMeshes();
        var gridObj = new GameObject();
        gridObj.name = "Grid";
        var tilesObj = new GameObject();
        tilesObj.transform.parent = gridObj.transform;
        tilesObj.name = "Tiles";
        var actorsObj = new GameObject();
        actorsObj.transform.parent = gridObj.transform;
        actorsObj.name = "Actors";

        /////////////////////////////////////////////////////
        /////////////////////////////////////////////////////
        /// Create your own algorithm & logic to create the grid shape and size you want, and assign 
        /// the correct owner to tiles to create borderer territories. Replace Grid class with your own based on HexGrid
        var grid = new Demo_HexGrid(gridObj, tilesObj, actorsObj, new Vector2(GridSizeX, GridSizeY), HexTileRadius, _hexTileWidth);
         
        for (int i = 0; i < GridSizeX; i++)
        {
            for (int j = 0; j < GridSizeY; j++)
            {
                if (j == GridSizeY - 1 && i % 2 == 1)
                    continue;

                CreateTile(i, j, grid, GetOwnerNumForPos(i, j));
            }
        }
        CreateTile(5, -1, grid, GetOwnerNumForPos(5, -1));
        CreateTile(5, GridSizeY - 1, grid, GetOwnerNumForPos(5, GridSizeY - 1));

        /////////////////////////////////////////////////////
        /////////////////////////////////////////////////////

        CreatePlayerTerritoryBorders(grid, gridObj);
        return grid;
    }

    // Override this method, and add your component that inherits from HexTile
    override protected void CreateTile(int x, int y, HexGrid grid, int owner)
    {
        var hexTileObject = new GameObject();
        var hexTile = new Demo_HexTile(hexTileObject);
        CreateHexTileAt(hexTile, x, y, grid, owner);
    }

    // Override this method, and add your component that inherits from HexGridActor
    override protected HexGridActor CreateActor(string objName, Vector2 pos, HexGrid grid, int owner, GameObject actorView)
    {
        var actorObj = new GameObject();
        actorObj.name = objName;
        var actor = new Demo_HexGridActor(actorObj);
        CreateHexGridActorAt(actor, pos, grid, owner, actorView);
        return actor;
    }

    // Owner assignment logic, this one will create 2 opposing territories separated by a few tiles of a 3rd territory
    public int GetOwnerNumForPos(int x, int y)
    {
        if (_gridPreset == 0 || _gridPreset == 2)
            return 0;

        int ownerNum = 0;
        if (x % 2 == 0)
        {
            if (y < GridSizeY / 2)
                ownerNum = 0;
            else
                ownerNum = 1;
        }
        else
        {
            if (y < (GridSizeY - 2) / 2)
                ownerNum = 0;
            else if (y > (GridSizeY - 2) / 2)
                ownerNum = 1;
            else
                ownerNum = 2;
        }  

        return ownerNum;
    }

    // Tile event handlers
    public void OnTileClicked(object sender, GridEventInfo eventInfo)
    {
        switch (eventInfo.Event)
        {
            case GridEvent.TileMouseDownL:
            {   // Move path start
                _pathStart = eventInfo.Tile.Pos;
                _grid.RemoveActor(_startActor);
                _startActor = CreateActor("Start " + eventInfo.Tile.Pos, eventInfo.Tile.Pos, _grid, 0, StartPrefab);
                
                if (_pathEnd != new Vector2(-1, -1))
                    UpdateAllActorsPathfind();
                break;
            }
            case GridEvent.TileMouseDownR:
            {   // Move path end
                _pathEnd = eventInfo.Tile.Pos;
                _grid.RemoveActor(_endActor);
                _endActor = CreateActor("End " + eventInfo.Tile.Pos, eventInfo.Tile.Pos, _grid, 0, EndPrefab);

                if (_pathStart != new Vector2(-1, -1))
                    UpdateAllActorsPathfind();
                break;
            }
            case GridEvent.TileMouseDownM:
            {
                // Add / Remove Wall To tile
                if (eventInfo.Tile.Accessibility == TileAccessibility.Accessible)
                    CreateBlockerTree(eventInfo.Tile);
                else
                {
                    List<HexGridActor> actors;
                    _grid.GetActorsAt(eventInfo.Tile.Pos, out actors);
                    foreach(HexGridActor actor in actors)
                        _grid.RemoveActor(actor);
                    eventInfo.Tile.Accessibility = TileAccessibility.Accessible;
                }

                if (_pathStart != new Vector2(-1, -1) && _pathEnd != new Vector2(-1, -1))
                    UpdateAllActorsPathfind();
                break;
            }
        }
    }

    public void OnTileEnter(object sender, GridEventInfo eventInfo)
    { 
        //Debug.Log("Entered " + eventInfo.Tile.Pos);

        // Get neighbours in range of cursor and change their overlay
        List<HexTile> tiles;
        _grid.GetTileNeighbours(out tiles, eventInfo.Tile.Pos, HoverOverlayRange);
        tiles.Add(eventInfo.Tile);
        foreach (HexTile tile in tiles)
        {
            _grid.SetOverlayMaterial(tile, HexTileOverlayMats[HoverOverlayIdxToApply]);
            _grid.SetOverlayColor(tile, TerritoryOverlayColor[tile.Owner]);
        }
    }

    public void OnTileExit(object sender, GridEventInfo eventInfo)
    {
        //Debug.Log("Exited " + eventInfo.Tile.Pos);

        // Reset overlays across the board
        _grid.SetOverlayMaterial(0, HexTileOverlayMats[TerritoryOverlayIdx[0]]);
        _grid.SetOverlayMaterial(1, HexTileOverlayMats[TerritoryOverlayIdx[1]]);
        _grid.SetOverlayMaterial(2, HexTileOverlayMats[TerritoryOverlayIdx[2]]);
        _grid.SetOverlayColor(0, TerritoryOverlayColor[0]);
        _grid.SetOverlayColor(1, TerritoryOverlayColor[1]);
        _grid.SetOverlayColor(2, TerritoryOverlayColor[2]);
    }

    // Called by Demo_UI
    public void ChangeTileViews(int owner, int viewIdx)
    {
        Material[] materials = new Material[2];
        materials[0] = HexTileBaseMats[viewIdx];
        materials[1] = HexTileSkirtMats[viewIdx];
        _grid.SetTileMaterial(owner, materials);
    }

    public void ChangeTileOverlay(int owner, int overlayIdx)
    {
        _grid.SetOverlayMaterial(owner, HexTileOverlayMats[overlayIdx]);
    }

    public void ChangeTileOverlayColor(int owner, Color color)
    {
        _grid.SetOverlayColor(owner, color);
    }

    public void ChangeGridOverlayColor(Color color)
    {
        _grid.SetGridOverlayColor(color);
    }

    public void ChangeTerritoryBorderColor(int owner, Color color)
    {
        _grid.SetBorderColor(owner, color);
    }

    public void ApplyPreset(int presetNum)
    {
        _gridPreset = presetNum;
        if (_grid != null)
        {
            if (_startActor != null && _startActor.Obj != null)
                Destroy(_startActor.Obj);
            if (_endActor != null && _endActor.Obj != null)
                Destroy(_endActor.Obj);

            if (_grid.TilesObj != null)
                Destroy(_grid.Obj);
            foreach (HexGridActor actor in _grid.Actors)
                Destroy(actor.Obj);
            _grid.Actors.Clear();
            _grid = null;
            _pathStart = new Vector2(-1, -1);
            _pathEnd = new Vector2(-1, -1);
            _endActor = null;
            _startActor = null;

        }

        _grid = CreateDemoHexGrid();
        _grid.TileMouseDownL += OnTileClicked;  // Subscribe to the TileMouseDownL  Event
        _grid.TileMouseDownR += OnTileClicked;  // Subscribe to the TileMouseDownR  Event
        _grid.TileMouseDownM += OnTileClicked;  // Subscribe to the TileMouseDownM  Event
        _grid.TileMouseEnter += OnTileEnter;    // Subscribe to the TileMouseEnter Event
        _grid.TileMouseExit  += OnTileExit;     // Subscribe to the TileMouseExit  Event

        Vector2 actorSpawn = Vector2.zero;
        Vector2 actorTarget = Vector2.zero;
        switch (presetNum)
        {
            case 0:
                {
                    ChangeTileViews(0, 2);
                    ChangeTerritoryBorderColor(0, new Color(0, 0.4f, 0));
                    ChangeTileOverlayColor(0, new Color(0, 0.4f, 0));
                    actorSpawn = new Vector2(0, 0);
                    //actorSpawn = new Vector2(10, 2);
                    actorTarget = new Vector2(10, 0);

                    Vector2[] blockerPositions = new Vector2[35];
                    GetBlockerPositions(ref blockerPositions);
                    foreach(Vector2 pos in blockerPositions)
                        CreateBlockerTree(_grid.Tiles[pos]);
                    break;
                }
            case 1:
                {
                    ChangeTileViews(0, 3);
                    ChangeTileViews(1, 1);
                    ChangeTileViews(2, 0);
                    ChangeTerritoryBorderColor(0, new Color(1, 0, 0));
                    ChangeTerritoryBorderColor(1, new Color(0, 0, 1));
                    ChangeTerritoryBorderColor(2, new Color(1, 1, 1));
                    ChangeTileOverlay(0, 2);
                    ChangeTileOverlay(1, 2);
                    ChangeTileOverlay(2, 2);
                    ChangeTileOverlayColor(0, new Color(0.4f, 0, 0));
                    ChangeTileOverlayColor(1, new Color(0, 0, 0.4f));
                    ChangeTileOverlayColor(2, new Color(0.4f, 0.4f, 0.4f));

                    Vector2[] blockerPositions = new Vector2[8];
                    GetBlockerPositions(ref blockerPositions);
                    foreach (Vector2 pos in blockerPositions)
                        CreateBlockerTree(_grid.Tiles[pos]);

                    break;
                }
            case 2:
                {
                    ChangeTerritoryBorderColor(0, new Color(1, 0.6f, 0));
                    break;
                }
        }

        if (!(actorSpawn == Vector2.zero && actorTarget == Vector2.zero))
        {
            _startActor = CreateActor("Start " + actorSpawn, actorSpawn, _grid, 0, StartPrefab);
            _endActor = CreateActor("End " + actorTarget, actorTarget, _grid, 0, EndPrefab);
            _pathStart = _startActor.Pos;
            _pathEnd = _endActor.Pos;
            UpdateDisplayPathAStar();
        }
    }

    private HexGridActor CreateBlockerTree(HexTile tile)
    {
        HexGridActor blocker = CreateActor("Tree " + tile.Pos, tile.Pos, _grid, 0, BlockerPrefab);
        Vector3 rot = new Vector3();
        rot.y += UnityEngine.Random.Range(0, 360);
        blocker.Obj.transform.localRotation = Quaternion.Euler(rot);
        tile.Accessibility = TileAccessibility.Blocked;
        return blocker;
    }

    private void GetBlockerPositions(ref Vector2[] blockerPositions)
    {
        if (_gridPreset == 0)
        {
            blockerPositions[0]  = new Vector2(1f, 0f);
            blockerPositions[1]  = new Vector2(1f, 1f);
            blockerPositions[2]  = new Vector2(1f, 2f);
            blockerPositions[3]  = new Vector2(1f, 3f);
            blockerPositions[4]  = new Vector2(1f, 4f);
            blockerPositions[5]  = new Vector2(1f, 5f);
            blockerPositions[6]  = new Vector2(2f, 0f);
            blockerPositions[7]  = new Vector2(3f, 1f);
            blockerPositions[8]  = new Vector2(3f, 2f);
            blockerPositions[9]  = new Vector2(3f, 3f);
            blockerPositions[10] = new Vector2(3f, 4f);
            blockerPositions[11] = new Vector2(3f, 5f);
            blockerPositions[12] = new Vector2(3f, 6f);
            blockerPositions[13] = new Vector2(4f, 0f);
            blockerPositions[14] = new Vector2(5f, 0f);
            blockerPositions[15] = new Vector2(5f, 1f);
            blockerPositions[16] = new Vector2(5f, 2f);
            blockerPositions[17] = new Vector2(5f, 3f);
            blockerPositions[18] = new Vector2(5f, 4f);
            blockerPositions[19] = new Vector2(5f, 5f);
            blockerPositions[20] = new Vector2(5f, 6f);
            blockerPositions[21] = new Vector2(6f, 0f);
            blockerPositions[22] = new Vector2(7f, 1f);
            blockerPositions[23] = new Vector2(7f, 2f);
            blockerPositions[24] = new Vector2(7f, 3f);
            blockerPositions[25] = new Vector2(7f, 4f);
            blockerPositions[26] = new Vector2(7f, 5f);
            blockerPositions[27] = new Vector2(7f, 6f);
            blockerPositions[28] = new Vector2(8f, 0f);
            blockerPositions[29] = new Vector2(9f, 0f);
            blockerPositions[30] = new Vector2(9f, 1f);
            blockerPositions[31] = new Vector2(9f, 2f);
            blockerPositions[32] = new Vector2(9f, 3f);
            blockerPositions[33] = new Vector2(9f, 4f);
            blockerPositions[34] = new Vector2(9f, 5f);    
        }
        else if (_gridPreset == 1)
        {
            blockerPositions[0] = new Vector2(1f, 1f);
            blockerPositions[1] = new Vector2(4f, 1f);
            blockerPositions[2] = new Vector2(7f, 0f);
            blockerPositions[3] = new Vector2(10f, 3f);
            blockerPositions[4] = new Vector2(2f, 4f);
            blockerPositions[5] = new Vector2(5f, 5f);
            blockerPositions[6] = new Vector2(6f, 5f);
            blockerPositions[7] = new Vector2(8f, 5f);
        }
    }
}
