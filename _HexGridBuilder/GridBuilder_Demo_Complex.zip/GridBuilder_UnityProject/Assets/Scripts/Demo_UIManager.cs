﻿/* 
 * Demo for the Hex Grid Builder
 * https://github.com/tombbonin
 */ 

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Demo_UIManager : MonoBehaviour 
{
    private int _selectedTerritory;

    public Demo_HexGridBuilder HexGridBuilder;
    public Button[] TerritoryButtons;
    public Button[] ViewIdxButtons;
    public Button[] OverlayIdxButtons;
    public Button[] ColorEditButtons;
    public Button[] HoverOverlayIdxButtons;
    public Button[] PresetButtons;
    public Slider Slider_R;
    public Slider Slider_G;
    public Slider Slider_B;
    
    private class TerritoryInfo
    {
        public int      ViewIdx;
        public int      OverlayIdx;
        public Color    OverlayColor;
        public Color    BorderColor;

        public TerritoryInfo()
        {
            ViewIdx = 0;
            OverlayIdx = 0;
            OverlayColor = Color.white;
            BorderColor = Color.white;
        }
    }
    private TerritoryInfo[] _territoryInfo = new TerritoryInfo[3];
    private Color _gridOverlayColor;
    private int _hoverOverlayIdx;
    private int _presetNum;

    public enum ColorEditing { Grid, Overlay, Border }
    private ColorEditing _currentlyEditing = ColorEditing.Overlay;

	void Start()
    {
        _territoryInfo[0] = new TerritoryInfo();
        _territoryInfo[1] = new TerritoryInfo();
        _territoryInfo[2] = new TerritoryInfo();

        _gridOverlayColor = Color.black;
        HexGridBuilder.TerritoryOverlayColor[0] = Color.white;
        HexGridBuilder.TerritoryOverlayColor[1] = Color.white;
        HexGridBuilder.TerritoryOverlayColor[2] = Color.white;

        ButtonEvent_SelectPreset(0);
        ButtonEvent_SelectTerritory(0);
        ButtonEvent_SelectColorEdit(1);
        ButtonEvent_SetHoverOverlay(2);
    }

	void Update() { }

    public void ButtonEvent_SelectPreset(int num)
    {
        _presetNum = num;
        HexGridBuilder.ApplyPreset(_presetNum);

        for (int i = 0; i < PresetButtons.Length; i++)
            PresetButtons[i].interactable = (i != num);

        switch (_presetNum)
        {
            case 0:
            {
                TerritoryButtons[1].gameObject.SetActive(false);
                TerritoryButtons[2].gameObject.SetActive(false);

                _territoryInfo[0].BorderColor = new Color(0, 0.4f, 0);
                _territoryInfo[0].ViewIdx = 2;
                _territoryInfo[0].OverlayIdx = 0;
                _territoryInfo[0].OverlayColor = new Color(0, 0.4f, 0);

                _gridOverlayColor = new Color(0, 0, 0);
                ButtonEvent_SelectColorEdit(0);

                ButtonEvent_SelectTerritory(0);
                ButtonEvent_SetTileOverlay(0);
                ButtonEvent_SetTileView(2);

                ButtonEvent_SetHoverOverlay(2);  
                ButtonEvent_SelectColorEdit(1);
                break;
            }
            case 1:
            {
                TerritoryButtons[1].gameObject.SetActive(true);
                TerritoryButtons[2].gameObject.SetActive(true);

                _territoryInfo[0].BorderColor = new Color(1, 0, 0);
                _territoryInfo[0].ViewIdx = 3;
                _territoryInfo[0].OverlayIdx = 2;
                _territoryInfo[0].OverlayColor = new Color(0.4f, 0, 0);

                _territoryInfo[1].BorderColor = new Color(0, 0, 1);
                _territoryInfo[1].ViewIdx = 1;
                _territoryInfo[1].OverlayIdx = 2;
                _territoryInfo[1].OverlayColor = new Color(0, 0, 0.4f);

                _territoryInfo[2].BorderColor = new Color(1, 1, 1);
                _territoryInfo[2].ViewIdx = 0;
                _territoryInfo[2].OverlayIdx = 2;
                _territoryInfo[2].OverlayColor = new Color(0.4f, 0.4f, 0.4f);

                ButtonEvent_SelectTerritory(0);
                HexGridBuilder.ChangeTileOverlayColor(0, _territoryInfo[0].OverlayColor);
                ButtonEvent_SelectColorEdit(1);
                ButtonEvent_SetTileOverlay(2);

                ButtonEvent_SelectTerritory(1);
                HexGridBuilder.ChangeTileOverlayColor(1, _territoryInfo[1].OverlayColor);
                ButtonEvent_SelectColorEdit(1);
                ButtonEvent_SetTileOverlay(2);

                ButtonEvent_SelectTerritory(2);
                HexGridBuilder.ChangeTileOverlayColor(2, _territoryInfo[2].OverlayColor);
                ButtonEvent_SelectColorEdit(1);
                ButtonEvent_SetTileOverlay(2);

                _gridOverlayColor = new Color(0, 0, 0);
                ButtonEvent_SelectColorEdit(0);

                ButtonEvent_SelectTerritory(0);
                ButtonEvent_SetTileView(3);
                ButtonEvent_SetHoverOverlay(1);
                ButtonEvent_SelectColorEdit(1);
                break;
            }
            case 2:
            {
                TerritoryButtons[1].gameObject.SetActive(false);
                TerritoryButtons[2].gameObject.SetActive(false);

                _territoryInfo[0].BorderColor = new Color(1, 0.6f, 0);
                _territoryInfo[0].ViewIdx = 0;
                _territoryInfo[0].OverlayIdx = 0;
                _territoryInfo[0].OverlayColor = new Color(0.75f, 0.4f, 0f);

                _gridOverlayColor = new Color(0, 0, 0);
                ButtonEvent_SelectColorEdit(0);

                ButtonEvent_SelectTerritory(0);
                ButtonEvent_SetTileOverlay(0);
                ButtonEvent_SetTileView(0);

                ButtonEvent_SetHoverOverlay(2);
                ButtonEvent_SelectColorEdit(1);
                break;
            }
        }
    }

    public void ButtonEvent_SelectColorEdit(int colorEdit)
    {
        _currentlyEditing = (ColorEditing)colorEdit;
        for (int i = 0; i < ColorEditButtons.Length; i++)
            ColorEditButtons[i].interactable = (i != (int)colorEdit);

        if (_currentlyEditing == ColorEditing.Grid)
        {
            Slider_R.value = _gridOverlayColor.r;
            Slider_G.value = _gridOverlayColor.g;
            Slider_B.value = _gridOverlayColor.b;
        }
        else if (_currentlyEditing == ColorEditing.Overlay)
        {
            Slider_R.value = _territoryInfo[_selectedTerritory].OverlayColor.r;
            Slider_G.value = _territoryInfo[_selectedTerritory].OverlayColor.g;
            Slider_B.value = _territoryInfo[_selectedTerritory].OverlayColor.b;
        }
        else // Border
        {
            Slider_R.value = _territoryInfo[_selectedTerritory].BorderColor.r;
            Slider_G.value = _territoryInfo[_selectedTerritory].BorderColor.g;
            Slider_B.value = _territoryInfo[_selectedTerritory].BorderColor.b;
        }  
    }

    public void ButtonEvent_SelectTerritory(int num)
    {
        _selectedTerritory = num;

        for (int i = 0; i < TerritoryButtons.Length; i++)
                TerritoryButtons[i].interactable = (i != num);

        for (int i = 0; i < ViewIdxButtons.Length; i++)
            ViewIdxButtons[i].interactable = (i != _territoryInfo[num].ViewIdx);

        for (int i = 0; i < OverlayIdxButtons.Length; i++)
            OverlayIdxButtons[i].interactable = (i != _territoryInfo[num].OverlayIdx);

        ButtonEvent_SelectColorEdit((int)_currentlyEditing);
    }

    public void ButtonEvent_SetTileView(int viewIdx)
    {
        _territoryInfo[_selectedTerritory].ViewIdx = viewIdx;
        for (int i = 0; i < ViewIdxButtons.Length; i++)
            ViewIdxButtons[i].interactable = (i != viewIdx);

        HexGridBuilder.ChangeTileViews(_selectedTerritory, viewIdx);
    }

    public void ButtonEvent_SetTileOverlay(int overlayIdx)
    {
        _territoryInfo[_selectedTerritory].OverlayIdx = overlayIdx;
        for (int i = 0; i < OverlayIdxButtons.Length; i++)
            OverlayIdxButtons[i].interactable = (i != overlayIdx);

        HexGridBuilder.ChangeTileOverlay(_selectedTerritory, overlayIdx);
        HexGridBuilder.ChangeTileOverlayColor(_selectedTerritory, _territoryInfo[_selectedTerritory].OverlayColor);

        HexGridBuilder.TerritoryOverlayIdx[_selectedTerritory] = overlayIdx;
    }

    public void ButtonEvent_SetHoverOverlay(int hoverOverlayIdx)
    {
        _hoverOverlayIdx = hoverOverlayIdx;
        for (int i = 0; i < HoverOverlayIdxButtons.Length; i++)
            HoverOverlayIdxButtons[i].interactable = (i != _hoverOverlayIdx);

        HexGridBuilder.HoverOverlayIdxToApply = _hoverOverlayIdx;
    }

    public void SliderEvent_ColorValueChanged(Slider slider)
    {
        Color color = new Color();
        if (_currentlyEditing == ColorEditing.Grid)
            color = _gridOverlayColor;
        else if (_currentlyEditing == ColorEditing.Overlay)
            color = _territoryInfo[_selectedTerritory].OverlayColor;
        else
            color = _territoryInfo[_selectedTerritory].BorderColor;

        if(slider == Slider_R)
            color.r = Slider_R.value;
        else if(slider == Slider_G)
            color.g = Slider_G.value;
        else
            color.b = Slider_B.value;

        if (_currentlyEditing == ColorEditing.Grid)
        {
            HexGridBuilder.ChangeGridOverlayColor(color);
            _gridOverlayColor = color;
        }
        else if (_currentlyEditing == ColorEditing.Overlay)
        {
            HexGridBuilder.ChangeTileOverlayColor(_selectedTerritory, color);
            _territoryInfo[_selectedTerritory].OverlayColor = color;
            HexGridBuilder.TerritoryOverlayColor[_selectedTerritory] = color;
        }
        else // Border
        {
            HexGridBuilder.ChangeTerritoryBorderColor(_selectedTerritory, color);
            _territoryInfo[_selectedTerritory].BorderColor = color;
        }        
    }

    public void SliderEvent_OverlaySizeValueChanged(Slider slider)
    {
        HexGridBuilder.HoverOverlayRange = (int)slider.value;
    }
}
