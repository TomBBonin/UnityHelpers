﻿/* 
 * "Complex" Demo for the Hex Grid Builder
 * For the bare bones check the Git Repo
 * 
 * https://github.com/tombbonin
 */ 

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

// Create your own HexGridActor class
public class Demo_HexGridActor : HexGridActor
{
    public Demo_HexGridActor(GameObject obj) : base(obj) { }
}

// Create your own HexTile class
public class Demo_HexTile : HexTile
{
    public Demo_HexTile(GameObject obj) : base(obj) { }
}

// Create your own HexGrid Class
public class Demo_HexGrid : HexGrid
{
    public Demo_HexGrid(GameObject obj,GameObject tilesObj, GameObject actorsObj, Vector2 size, float radius, float width) : base(obj, tilesObj, actorsObj, size, radius, width) { }
}

// Create your own GridBuilder Class
public class Demo_HexGridBuilder : HexGridBuilder
{
    private Demo_HexGrid _grid;

    private void Update()
    {
        if (_grid != null)
            _grid.Execute(Time.deltaTime);
        else
        {
            // Create Grid
            _grid = CreateDemoHexGrid();

            // Subscribe to all the grid events
            _grid.TileMouseDownL += OnTileClicked;  // Subscribe to the TileMouseDownL  Event
            _grid.TileMouseDownR += OnTileClicked;  // Subscribe to the TileMouseDownR  Event
            _grid.TileMouseDownM += OnTileClicked;  // Subscribe to the TileMouseDownM  Event
            _grid.TileMouseEnter += OnTileEnter;    // Subscribe to the TileMouseEnter Event
            _grid.TileMouseExit  += OnTileExit;     // Subscribe to the TileMouseExit  Event
        }
    }

    // Using the base method CreateHexGrid() as an example, create yor own grid building method 
    // Change the new HexGrid call to use your class that inherits from HexGrid
    // Add or remove any Tiles as you see fit this demo for a more appealing and symetrical board
    // You can use the owner parameter to affect an owner to tiles. Every owner's group of tiles will have their own border. 
    //     Remember to add one material per owner to the border overlays.
    private Demo_HexGrid CreateDemoHexGrid()
    {
        ComputeHexDimensions();
        BuildMeshes();
        var gridObj = new GameObject();
        gridObj.name = "Grid";
        var tilesObj = new GameObject();
        tilesObj.transform.parent = gridObj.transform;
        tilesObj.name = "Tiles";
        var actorsObj = new GameObject();
        actorsObj.transform.parent = gridObj.transform;
        actorsObj.name = "Actors";

        /////////////////////////////////////////////////////
        /////////////////////////////////////////////////////
        /// Create your own algorithm & logic to create the grid shape and size you want, and assign 
        /// the correct owner to tiles to create borderer territories. Replace Grid class with your own based on HexGrid
        var grid = new Demo_HexGrid(gridObj, tilesObj, actorsObj, new Vector2(GridSizeX, GridSizeY), HexTileRadius, _hexTileWidth);
        int ownerNum = 0;
        for (int i = 0; i < GridSizeX; i++)
            for (int j = 0; j < GridSizeY; j++)
                CreateTile(i, j, grid, ownerNum);

        /////////////////////////////////////////////////////
        /////////////////////////////////////////////////////

        CreatePlayerTerritoryBorders(grid, gridObj);
        return grid;
    }

    // Override this method, and add your component that inherits from HexTile
    override protected void CreateTile(int x, int y, HexGrid grid, int owner)
    {
        var hexTileObject = new GameObject();
        var hexTile = new Demo_HexTile(hexTileObject);
        CreateHexTileAt(hexTile, x, y, grid, owner);
    }

    // Override this method, and add your component that inherits from HexGridActor
    override protected HexGridActor CreateActor(string objName, Vector2 pos, HexGrid grid, int owner, GameObject actorView)
    {
        var actorObj = new GameObject();
        actorObj.name = objName;
        var actor = new Demo_HexGridActor(actorObj);
        CreateHexGridActorAt(actor, pos, grid, owner, actorView);
        return actor;
    }

    // Tile event handlers
    public void OnTileClicked(object sender, GridEventInfo eventInfo)
    {
        Debug.Log("Clicked " + eventInfo.Tile.Pos);
    }

    public void OnTileEnter(object sender, GridEventInfo eventInfo)
    {
        //Debug.Log("Entered " + eventInfo.Tile.Pos);
    }

    public void OnTileExit(object sender, GridEventInfo eventInfo)
    {
        //Debug.Log("Exited " + eventInfo.Tile.Pos);
    }

}
